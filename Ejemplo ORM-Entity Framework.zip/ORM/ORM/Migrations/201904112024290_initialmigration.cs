namespace ORM.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initialmigration : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Clientes",
                c => new
                    {
                        IdCliente = c.Int(nullable: false, identity: true),
                        Nombre = c.String(),
                        Direccion = c.String(),
                        Genero = c.String(),
                        Edad = c.Int(nullable: false),
                        Telefono = c.String(),
                        Departamento_IdDepartamento = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.IdCliente)
                .ForeignKey("dbo.Departamentoes", t => t.Departamento_IdDepartamento)
                .Index(t => t.Departamento_IdDepartamento);
            
            CreateTable(
                "dbo.Departamentoes",
                c => new
                    {
                        IdDepartamento = c.String(nullable: false, maxLength: 128),
                        IdCliente = c.String(),
                        Nombre = c.String(),
                    })
                .PrimaryKey(t => t.IdDepartamento);
            
            CreateTable(
                "dbo.Empleadoes",
                c => new
                    {
                        IdEmpleado = c.Int(nullable: false, identity: true),
                        IdMunicipio = c.String(),
                        Nombre = c.String(),
                        Apellidos = c.String(),
                        Direccion = c.String(),
                        Telefono = c.String(),
                        Correo = c.String(),
                        Cargo = c.String(),
                        Clave = c.String(),
                    })
                .PrimaryKey(t => t.IdEmpleado);
            
            CreateTable(
                "dbo.Municipios",
                c => new
                    {
                        Nombre = c.String(nullable: false, maxLength: 128),
                        IdDepartamento = c.String(maxLength: 128),
                        imagen = c.Binary(),
                        Empleado_IdEmpleado = c.Int(),
                    })
                .PrimaryKey(t => t.Nombre)
                .ForeignKey("dbo.Departamentoes", t => t.IdDepartamento)
                .ForeignKey("dbo.Empleadoes", t => t.Empleado_IdEmpleado)
                .Index(t => t.IdDepartamento)
                .Index(t => t.Empleado_IdEmpleado);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Municipios", "Empleado_IdEmpleado", "dbo.Empleadoes");
            DropForeignKey("dbo.Municipios", "IdDepartamento", "dbo.Departamentoes");
            DropForeignKey("dbo.Clientes", "Departamento_IdDepartamento", "dbo.Departamentoes");
            DropIndex("dbo.Municipios", new[] { "Empleado_IdEmpleado" });
            DropIndex("dbo.Municipios", new[] { "IdDepartamento" });
            DropIndex("dbo.Clientes", new[] { "Departamento_IdDepartamento" });
            DropTable("dbo.Municipios");
            DropTable("dbo.Empleadoes");
            DropTable("dbo.Departamentoes");
            DropTable("dbo.Clientes");
        }
    }
}
