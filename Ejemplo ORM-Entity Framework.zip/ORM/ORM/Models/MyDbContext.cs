﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace ORM.Models
{
    public class MyDbContext: DbContext
    {
        public MyDbContext():base("conexion")
        {
 
        }
        #region
        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<Empleado> Empleados { get; set; }
        public DbSet<Municipio> Municipio { get; set; }

        public DbSet<Departamento> Departamento { get; set; }

        #endregion
    }
}