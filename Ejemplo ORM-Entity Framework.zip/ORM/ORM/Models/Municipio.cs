﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ORM.Models
{
    public class Municipio
    {
     
        public string IdDepartamento { get; set; }
        [Key]
       
      
        public string Nombre { get; set; }
        public byte[] imagen { get; set; }

        public virtual Departamento Depto { get; set; }
        public virtual Empleado Empleado { get; set; }
        
    }
}