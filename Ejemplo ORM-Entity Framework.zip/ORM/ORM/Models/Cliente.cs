﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ORM.Models
{
    public class Cliente
    {
        [Key]
        public int IdCliente { get; set; }
       
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Genero { get; set; }
        public int Edad { get; set; }
        public string Telefono { get; set; }
        public virtual Departamento Departamento { get; set; }
    }
}